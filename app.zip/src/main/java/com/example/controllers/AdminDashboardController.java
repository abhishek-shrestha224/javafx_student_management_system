package com.example.controllers;

public class AdminDashboardController extends DashboardController {
}
